
$(function() {
  alert("hello");
  alert(final_result);
    let availableTags = ['Ashvini', 'Ashu', 'Ridhima']
    $( "#tags" ).autocomplete({
      source: availableTags
    });
  });

