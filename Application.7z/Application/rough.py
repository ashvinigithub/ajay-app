# import os
# import os.path
# import sqlite3 


# basedir = os.path.abspath(os.path.dirname(__file__))
# dbpath = os.path.join(basedir, r'database/sqlite-ajay-db.db')
# # dbpath = os.path.join(basedir, 'sunnydb.db')
# # dbpath = r"C:\Users\Win10-GP76\Documents\Coding\ajay-app\Application\database\sqlite-ajay-db.db"
# # BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# # dbpath = (BASE_DIR + '\\sunnydb.db')

# # conn = sqlite3.connect(dbpath)
# # conn.row_factory = sqlite3.Row
# # cursor = conn.cursor()
# # print("Opened database successfully")
# # dataset = conn.execute('''
# #     INSERT INTO ajay_app_gold_rate_master (METAL_TYPE, PURITY, RATE, RATE_DATE, INSERT_DATE) 
# #     VALUES('TEST', '24k', 11000, current_date, CURRENT_TIMESTAMP);
# # ''')
# # conn.commit()
# # conn.close()
# # dict(list(enumerate(temp_list)))

# for i in range(10):
#     print(i+1)

rate_24k = 80000
rate_22k = float(22.00/24.00) * rate_24k
print(rate_22k)